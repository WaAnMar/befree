package com.befree.app.ui

import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Mood
import androidx.compose.material.icons.outlined.Waves
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.befree.app.MainViewModel
import com.befree.app.data.GoalType
import com.befree.app.security.PinManager
import com.befree.app.ui.craving.CravingEditorScreen
import com.befree.app.ui.craving.CravingScreen
import com.befree.app.ui.goals.GoalEditorScreen
import com.befree.app.ui.goals.GoalsScreen
import com.befree.app.ui.home.HomeScreen
import com.befree.app.ui.library.ArticleScreen
import com.befree.app.ui.library.LibraryScreen
import com.befree.app.ui.mood.MoodEditorScreen
import com.befree.app.ui.mood.MoodScreen
import com.befree.app.ui.settings.PrivacyScreen
import com.befree.app.ui.settings.SettingsScreen
import com.befree.app.ui.sos.SosScreen

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Главная", Icons.Outlined.Home),
    Mood("mood", "Настроение", Icons.Outlined.Mood),
    Craving("craving", "Тяга", Icons.Outlined.Waves),
    Goals("goals", "Цели", Icons.Outlined.Flag),
    Library("library", "Знания", Icons.AutoMirrored.Outlined.MenuBook),
}

@Composable
fun BeFreeRoot(vm: MainViewModel, pinManager: PinManager, onWipe: () -> Unit) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showBar = Tab.entries.any { it.route == route }

    fun go(r: String) = nav.navigate(r)
    fun back() { nav.popBackStack() }

    Scaffold(
        bottomBar = {
            if (showBar) NavigationBar {
                Tab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = route == tab.route,
                        onClick = {
                            nav.navigate(tab.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = null) },
                        label = { Text(tab.label, maxLines = 1) },
                    )
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = Tab.Home.route, modifier = Modifier.padding(padding).consumeWindowInsets(padding)) {
            composable(Tab.Home.route) {
                HomeScreen(
                    vm = vm,
                    onSettings = { go("settings") },
                    onSos = { go("sos") },
                    onQuickMood = { go("mood/new/$it") },
                    onLogCraving = { go("craving/new") },
                )
            }
            composable(Tab.Mood.route) { MoodScreen(vm, onNew = { go("mood/new/3") }) }
            composable(Tab.Craving.route) { CravingScreen(vm, onNew = { go("craving/new") }, onSos = { go("sos") }) }
            composable(Tab.Goals.route) { GoalsScreen(vm, onNew = { type -> go("goal/new/$type") }) }
            composable(Tab.Library.route) { LibraryScreen(onOpen = { id -> go("article/$id") }) }

            composable("mood/new/{level}", arguments = listOf(navArgument("level") { type = NavType.IntType })) {
                MoodEditorScreen(
                    initialMood = it.arguments?.getInt("level") ?: 3,
                    onSave = { entry -> vm.addMood(entry); back() },
                    onBack = ::back,
                )
            }
            composable("craving/new") {
                val addictions by vm.addictions.collectAsStateWithLifecycle()
                CravingEditorScreen(
                    addictionNames = addictions.map { a -> a.name },
                    onSave = { entry -> vm.addCraving(entry); back() },
                    onBack = ::back,
                )
            }
            composable("goal/new/{type}") {
                GoalEditorScreen(
                    initialType = it.arguments?.getString("type") ?: GoalType.PRACTICAL,
                    onSave = { goal -> vm.saveGoal(goal); back() },
                    onBack = ::back,
                )
            }
            composable("article/{id}") {
                ArticleScreen(id = it.arguments?.getString("id") ?: "", onBack = ::back)
            }
            composable("sos") {
                SosScreen(onBack = ::back, onLogCraving = {
                    nav.navigate("craving/new") { popUpTo("sos") { inclusive = true } }
                })
            }
            composable("settings") { SettingsScreen(pinManager, onBack = ::back, onPrivacy = { go("privacy") }, onWipe = onWipe) }
            composable("privacy") { PrivacyScreen(onBack = ::back) }
        }
    }
}
