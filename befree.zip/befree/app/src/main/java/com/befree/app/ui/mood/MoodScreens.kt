package com.befree.app.ui.mood

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.befree.app.MainViewModel
import com.befree.app.data.MoodEntry
import com.befree.app.data.emotionOptions
import com.befree.app.ui.components.*
import com.befree.app.util.*
import kotlin.math.roundToInt

@Composable
fun MoodScreen(vm: MainViewModel, onNew: () -> Unit) {
    val moods by vm.moods.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<MoodEntry?>(null) }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { ScreenHeader("Настроение", "Замечай, как ты себя чувствуешь") }
        item { Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Text("Отметить настроение") } }

        if (moods.isEmpty()) {
            item { EmptyState("🌤", "Пока нет записей", "Отмечай настроение хотя бы раз в день. Через неделю станет видно, как оно связано с тягой, сном и событиями.") }
        } else {
            item {
                SoftCard {
                    Text("Последние 14 дней", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    MoodChart(moods)
                }
            }
            val top = moods.filter { it.timestamp >= System.currentTimeMillis() - 30 * DAY_MS }
                .flatMap { it.emotions }.groupingBy { it }.eachCount()
                .entries.sortedByDescending { it.value }.take(5)
            if (top.isNotEmpty()) item {
                SoftCard {
                    Text("Чаще всего за месяц", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    val max = top.first().value
                    top.forEach { BarRow(it.key, it.value, max, MaterialTheme.colorScheme.secondary) }
                }
            }
            item { SectionTitle("История") }
            items(moods, key = { it.id }) { m -> MoodRow(m, onDelete = { toDelete = m }) }
        }
    }

    toDelete?.let { m ->
        ConfirmDialog("Удалить запись?", "Это действие нельзя отменить.", "Удалить",
            onConfirm = { vm.deleteMood(m); toDelete = null }, onDismiss = { toDelete = null })
    }
}

@Composable
private fun MoodChart(moods: List<MoodEntry>) {
    val days = 14
    val today = startOfDay(System.currentTimeMillis())
    val averages: List<Float?> = (days - 1 downTo 0).map { i ->
        val start = today - i * DAY_MS
        moods.filter { it.timestamp in start until start + DAY_MS }
            .map { it.mood }.takeIf { it.isNotEmpty() }?.average()?.toFloat()
    }
    val line = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outlineVariant

    Canvas(Modifier.fillMaxWidth().height(140.dp)) {
        val pad = 14f
        val w = size.width - 2 * pad
        val h = size.height - 2 * pad
        fun x(i: Int) = pad + i * w / (days - 1)
        fun y(v: Float) = pad + (1f - (v - 1f) / 4f) * h
        for (l in 1..5) drawLine(grid, Offset(pad, y(l.toFloat())), Offset(size.width - pad, y(l.toFloat())), strokeWidth = 1f)
        var prev: Offset? = null
        averages.forEachIndexed { i, v ->
            if (v != null) {
                val p = Offset(x(i), y(v))
                prev?.let { drawLine(line, it, p, strokeWidth = 5f, cap = StrokeCap.Round) }
                prev = p
            }
        }
        averages.forEachIndexed { i, v ->
            if (v != null) drawCircle(moodOf(v.roundToInt()).color, radius = 10f, center = Offset(x(i), y(v)))
        }
    }
    Row(Modifier.fillMaxWidth()) {
        Text("2 недели назад", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
        Text("сегодня", style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun MoodRow(m: MoodEntry, onDelete: () -> Unit) {
    val level = moodOf(m.mood)
    SoftCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(level.emoji, fontSize = 30.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("${level.label} · энергия ${m.energy}/5", fontWeight = FontWeight.SemiBold)
                Text(formatDateTime(m.timestamp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Outlined.Delete, contentDescription = "Удалить") }
        }
        if (m.emotions.isNotEmpty()) Text(m.emotions.joinToString(" · "), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
        if (m.note.isNotBlank()) Text(m.note, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun MoodEditorScreen(initialMood: Int, onSave: (MoodEntry) -> Unit, onBack: () -> Unit) {
    var mood by remember { mutableIntStateOf(initialMood.coerceIn(1, 5)) }
    var energy by remember { mutableFloatStateOf(3f) }
    var emotions by remember { mutableStateOf(setOf<String>()) }
    var note by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader("Как ты?", onBack = onBack)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            moodLevels.forEach { level -> MoodBubble(level, selected = mood == level.value) { mood = level.value } }
        }
        Text(moodOf(mood).label, Modifier.fillMaxWidth(), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium)

        SectionTitle("Энергия")
        Slider(value = energy, onValueChange = { energy = it }, valueRange = 1f..5f, steps = 3)
        Row(Modifier.fillMaxWidth()) {
            Text("Нет сил", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
            Text("Полон(на) сил", style = MaterialTheme.typography.labelSmall)
        }

        SectionTitle("Что ты чувствуешь?")
        ChipSelector(emotionOptions, emotions) { emotions = emotions.toggle(it) }

        SectionTitle("Заметка")
        OutlinedTextField(
            note, { note = it },
            placeholder = { Text("Что произошло? Что повлияло на настроение?") },
            minLines = 3, modifier = Modifier.fillMaxWidth(),
        )

        Button(
            onClick = { onSave(MoodEntry(mood = mood, energy = energy.roundToInt(), emotions = emotions.toList(), note = note.trim())) },
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text("Сохранить") }
    }
}
