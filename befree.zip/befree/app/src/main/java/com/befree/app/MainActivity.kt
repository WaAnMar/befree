package com.befree.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.befree.app.security.AppLock
import com.befree.app.ui.BeFreeRoot
import com.befree.app.ui.lock.LockScreen
import com.befree.app.ui.lock.SetupPinScreen
import com.befree.app.ui.theme.BeFreeTheme
import kotlin.system.exitProcess

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Запрет скриншотов, записи экрана и превью в списке недавних приложений
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()

        val container = (application as BeFreeApp).container

        setContent {
            BeFreeTheme {
                val locked by AppLock.locked.collectAsStateWithLifecycle()
                var hasPin by remember { mutableStateOf(container.pinManager.hasPin()) }

                when {
                    !hasPin -> SetupPinScreen(onDone = { pin ->
                        container.pinManager.setPin(pin)
                        hasPin = true
                        AppLock.unlock()
                    })
                    locked -> LockScreen(
                        pinManager = container.pinManager,
                        activity = this,
                        onUnlocked = { AppLock.unlock() },
                        onWipe = ::wipeAndExit,
                    )
                    else -> BeFreeRoot(
                        vm = viewModel(factory = MainViewModel.factory(container.dao)),
                        pinManager = container.pinManager,
                        onWipe = ::wipeAndExit,
                    )
                }
            }
        }
    }

    private fun wipeAndExit() {
        (application as BeFreeApp).container.wipeEverything()
        finishAffinity()
        exitProcess(0)
    }
}
