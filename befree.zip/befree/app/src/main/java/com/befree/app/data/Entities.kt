package com.befree.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Трекер «сколько я свободен(на)» — по одному на каждую зависимость. */
@Entity(tableName = "addictions")
data class Addiction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val soberSince: Long,
    val bestStreakMs: Long = 0,
    val costPerDay: Double = 0.0,
    val relapseCount: Int = 0,
)

@Entity(tableName = "moods")
data class MoodEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val mood: Int,              // 1..5
    val energy: Int,            // 1..5
    val emotions: List<String>,
    val note: String,
)

@Entity(tableName = "cravings")
data class CravingEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val addiction: String,
    val intensity: Int,         // 1..10
    val triggers: List<String>,
    val halt: List<String>,
    val place: String,
    val company: List<String>,
    val thoughts: String,
    val coping: List<String>,
    val durationMin: Int,
    val outcome: String,        // см. Outcome
    val note: String,
)

object Outcome {
    const val RESISTED = "resisted"
    const val PARTIAL = "partial"
    const val USED = "used"
}

@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,           // см. GoalType
    val title: String,
    val description: String = "",
    val person: String = "",    // для возмещения ущерба: кому
    val harm: String = "",      // для возмещения ущерба: что произошло
    val targetAmount: Double? = null,
    val paidAmount: Double = 0.0,
    val done: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val doneAt: Long? = null,
)

object GoalType {
    const val PRACTICAL = "practical"
    const val SPIRITUAL = "spiritual"
    const val AMENDS = "amends"
    val all = listOf(PRACTICAL, SPIRITUAL, AMENDS)
}
