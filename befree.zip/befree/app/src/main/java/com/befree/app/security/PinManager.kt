package com.befree.app.security

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.min

/** PIN хранится только как соль + PBKDF2-хэш. Сам PIN нигде не сохраняется. */
class PinManager(context: Context) {
    private val prefs = context.getSharedPreferences("befree_pin", Context.MODE_PRIVATE)

    fun hasPin(): Boolean = prefs.contains(HASH)

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString(SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(HASH, Base64.encodeToString(hash(pin, salt), Base64.NO_WRAP))
            .putInt(FAILS, 0).putLong(LOCK_UNTIL, 0)
            .commit()
    }

    fun verify(pin: String): Boolean {
        if (lockoutRemainingMs() > 0) return false
        val salt = Base64.decode(prefs.getString(SALT, null) ?: return false, Base64.NO_WRAP)
        val expected = Base64.decode(prefs.getString(HASH, null) ?: return false, Base64.NO_WRAP)
        val ok = MessageDigest.isEqual(expected, hash(pin, salt))
        if (ok) {
            prefs.edit().putInt(FAILS, 0).putLong(LOCK_UNTIL, 0).apply()
        } else {
            val fails = prefs.getInt(FAILS, 0) + 1
            val editor = prefs.edit().putInt(FAILS, fails)
            if (fails >= FREE_ATTEMPTS) {
                // 30 с, 60 с, 2 мин ... максимум 1 час
                val delay = min(30_000L shl min(fails - FREE_ATTEMPTS, 7), 3_600_000L)
                editor.putLong(LOCK_UNTIL, System.currentTimeMillis() + delay)
            }
            editor.apply()
        }
        return ok
    }

    fun lockoutRemainingMs(): Long =
        (prefs.getLong(LOCK_UNTIL, 0) - System.currentTimeMillis()).coerceAtLeast(0)

    var biometricEnabled: Boolean
        get() = prefs.getBoolean(BIO, false)
        set(v) { prefs.edit().putBoolean(BIO, v).apply() }

    fun clear() { prefs.edit().clear().commit() }

    private fun hash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    private companion object {
        const val SALT = "salt"; const val HASH = "hash"; const val FAILS = "fails"
        const val LOCK_UNTIL = "lock_until"; const val BIO = "bio"; const val FREE_ATTEMPTS = 5
    }
}
