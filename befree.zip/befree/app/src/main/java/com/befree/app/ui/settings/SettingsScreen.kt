package com.befree.app.ui.settings

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.befree.app.security.PinManager
import com.befree.app.security.canUseBiometric
import com.befree.app.ui.components.ScreenHeader
import com.befree.app.ui.components.SoftCard
import com.befree.app.ui.components.WipeDialog

@Composable
fun SettingsScreen(pinManager: PinManager, onBack: () -> Unit, onPrivacy: () -> Unit, onWipe: () -> Unit) {
    val context = LocalContext.current
    val bioAvailable = remember { canUseBiometric(context) }
    var bio by remember { mutableStateOf(pinManager.biometricEnabled) }
    var changePin by remember { mutableStateOf(false) }
    var wipe by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader("Настройки", onBack = onBack)

        SoftCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Вход по биометрии", fontWeight = FontWeight.SemiBold)
                    Text(
                        if (bioAvailable) "Отпечаток пальца или лицо" else "Недоступно на этом устройстве",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = bio && bioAvailable, enabled = bioAvailable, onCheckedChange = { bio = it; pinManager.biometricEnabled = it })
            }
        }

        SoftCard(onClick = { changePin = true }) {
            Text("Сменить PIN-код", fontWeight = FontWeight.SemiBold)
        }

        SoftCard(color = MaterialTheme.colorScheme.primaryContainer) {
            Text("🔒 Как защищены твои данные", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            listOf(
                "Всё хранится только на этом телефоне. У приложения нет разрешения на доступ к интернету — оно физически не может ничего отправить.",
                "База данных полностью зашифрована (SQLCipher, AES-256). Ключ защищён аппаратным хранилищем Android Keystore.",
                "Нет аккаунтов, рекламы, аналитики и трекеров.",
                "Облачное резервное копирование и перенос данных на другое устройство запрещены.",
                "Приложение блокируется, как только ты сворачиваешь его.",
                "Скриншоты и запись экрана запрещены, а в списке недавних приложений содержимое скрыто.",
                "PIN-код хранится только в виде криптографического хэша. После 5 неверных попыток ввод временно блокируется.",
            ).forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
        }

        SoftCard(onClick = {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "BeFree — приватный трекер восстановления от зависимости: $PLAY_URL")
            }
            runCatching { context.startActivity(Intent.createChooser(send, "Поделиться BeFree")) }
        }) {
            Text("📤 Поделиться приложением", fontWeight = FontWeight.SemiBold)
            Text("Отправь ссылку тому, кому это может помочь", style = MaterialTheme.typography.bodySmall)
        }

        SoftCard(onClick = {
            val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=io.github.waanmar.befree"))
            runCatching { context.startActivity(market) }
                .onFailure { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(PLAY_URL))) } }
        }) {
            Text("⭐ Оценить и оставить отзыв", fontWeight = FontWeight.SemiBold)
            Text("Твой отзыв в Google Play помогает сделать BeFree лучше", style = MaterialTheme.typography.bodySmall)
        }

        SoftCard(onClick = onPrivacy) {
            Text("Политика конфиденциальности", fontWeight = FontWeight.SemiBold)
        }

        SoftCard(color = MaterialTheme.colorScheme.errorContainer, onClick = { wipe = true }) {
            Text("Удалить все данные", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onErrorContainer)
            Text(
                "Безвозвратно стирает записи, цели, PIN-код и ключи шифрования.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer,
            )
        }

        Text("BeFree 1.0.0 · не является медицинским изделием", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }

    if (changePin) ChangePinDialog(pinManager, onDismiss = { changePin = false })
    if (wipe) WipeDialog(onConfirm = onWipe, onDismiss = { wipe = false })
}

@Composable
private fun ChangePinDialog(pinManager: PinManager, onDismiss: () -> Unit) {
    var old by remember { mutableStateOf("") }
    var new1 by remember { mutableStateOf("") }
    var new2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Сменить PIN-код") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PinField(old, "Текущий PIN") { old = it }
                PinField(new1, "Новый PIN (4–8 цифр)") { new1 = it }
                PinField(new2, "Повтори новый PIN") { new2 = it }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                error = when {
                    pinManager.lockoutRemainingMs() > 0 -> "Слишком много попыток, попробуй позже"
                    !pinManager.verify(old) -> "Текущий PIN неверный"
                    new1.length < 4 -> "Новый PIN слишком короткий"
                    new1 != new2 -> "Новые PIN-коды не совпадают"
                    else -> { pinManager.setPin(new1); onDismiss(); null }
                }
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
private fun PinField(value: String, label: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value, { v -> onChange(v.filter(Char::isDigit).take(8)) },
        label = { Text(label) }, singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
    )
}

@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ScreenHeader("Конфиденциальность", onBack = onBack)
        PRIVACY_POLICY.split("\n\n").forEach { block ->
            val lines = block.split("\n", limit = 2)
            if (lines.size == 2 && lines[0].length < 40) {
                Text(lines[0], style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(lines[1], style = MaterialTheme.typography.bodyLarge)
            } else {
                Text(block, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}
