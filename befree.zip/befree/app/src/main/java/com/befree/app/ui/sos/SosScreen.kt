package com.befree.app.ui.sos

import android.content.Intent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.befree.app.ui.components.ScreenHeader
import com.befree.app.ui.components.SoftCard
import kotlinx.coroutines.delay

private const val TIMER_SEC = 15 * 60

@Composable
fun SosScreen(onBack: () -> Unit, onLogCraving: () -> Unit) {
    val context = LocalContext.current
    val scale = remember { Animatable(0.6f) }
    var phase by remember { mutableStateOf("Вдох") }
    var left by remember { mutableIntStateOf(TIMER_SEC) }
    var running by remember { mutableStateOf(false) }
    var finished by remember { mutableStateOf(false) }

    // Дыхание 4 — 4 — 6
    LaunchedEffect(Unit) {
        while (true) {
            phase = "Вдох"; scale.animateTo(1f, tween(4_000, easing = LinearEasing))
            phase = "Задержи"; delay(4_000)
            phase = "Выдох"; scale.animateTo(0.6f, tween(6_000, easing = LinearEasing))
        }
    }
    LaunchedEffect(running) {
        while (running && left > 0) { delay(1_000); left-- }
        if (running && left == 0) { running = false; finished = true }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ScreenHeader("SOS", "Тяга — это волна. Она поднимется и спадёт.", onBack = onBack)

        Box(Modifier.fillMaxWidth().height(230.dp), contentAlignment = Alignment.Center) {
            val c = MaterialTheme.colorScheme.primary
            Box(
                Modifier.size(210.dp).scale(scale.value).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(c.copy(alpha = 0.55f), c.copy(alpha = 0.12f))))
            )
            Text(phase, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        }
        Text(
            "Дыши вместе с кругом: вдох на 4, пауза на 4, выдох на 6.",
            Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        SoftCard(color = MaterialTheme.colorScheme.primaryContainer) {
            Text("Правило 15 минут", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text("Пообещай себе подождать 15 минут, прежде чем что-то решать. За это время пик тяги обычно проходит.")
            if (finished) {
                Text("15 минут позади. Ты пережил(а) пик волны 💜 Как ты сейчас?", fontWeight = FontWeight.SemiBold)
            } else {
                Text(
                    "%02d:%02d".format(left / 60, left % 60),
                    style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                )
            }
            Button(onClick = {
                if (running) running = false
                else { if (left == 0 || finished) { left = TIMER_SEC; finished = false }; running = true }
            }, modifier = Modifier.fillMaxWidth()) {
                Text(if (running) "Пауза" else if (finished) "Ещё 15 минут" else "Запустить таймер")
            }
        }

        SoftCard {
            Text("Прямо сейчас", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            listOf(
                "Скажи себе: «Это тяга. Она временная. Я не обязан(а) ей подчиняться».",
                "Выпей стакан воды и съешь что-нибудь.",
                "Уйди из места, где сейчас находишься, — хотя бы в другую комнату или на улицу.",
                "Позвони или напиши человеку, которому доверяешь.",
                "Вспомни, ради чего ты начал(а). Загляни в свои цели.",
                "Назови 5 вещей, которые видишь, 4 — которые можешь потрогать, 3 звука вокруг.",
            ).forEachIndexed { i, s -> Text("${i + 1}. $s") }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_DIAL)) } },
                modifier = Modifier.weight(1f),
            ) { Text("📞 Позвонить") }
            Button(onClick = onLogCraving, modifier = Modifier.weight(1f)) { Text("Записать тягу") }
        }

        Text(
            "Если есть угроза жизни или признаки передозировки — звони 112 или на местный номер экстренной помощи.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error,
        )
    }
}
