package com.befree.app.ui.lock

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Backspace
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.befree.app.security.PinManager
import com.befree.app.security.canUseBiometric
import com.befree.app.security.showBiometricPrompt
import com.befree.app.ui.components.WipeDialog
import kotlinx.coroutines.delay

private const val MIN_PIN = 4
private const val MAX_PIN = 8

/** Своя цифровая клавиатура: системная клавиатура не видит PIN. */
@Composable
private fun PinPad(
    enabled: Boolean,
    confirmEnabled: Boolean,
    onDigit: (Char) -> Unit,
    onBackspace: () -> Unit,
    onConfirm: () -> Unit,
) {
    val rows = listOf("123", "456", "789", "<0>")
    Column(verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                row.forEach { key ->
                    val isConfirm = key == '>'
                    val keyEnabled = enabled && (!isConfirm || confirmEnabled)
                    val bg = when {
                        isConfirm && keyEnabled -> MaterialTheme.colorScheme.primary
                        isConfirm -> MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
                        else -> MaterialTheme.colorScheme.surfaceContainerHigh
                    }
                    Box(
                        Modifier.size(72.dp).clip(CircleShape).background(bg).clickable(enabled = keyEnabled) {
                            when (key) { '<' -> onBackspace(); '>' -> onConfirm(); else -> onDigit(key) }
                        },
                        contentAlignment = Alignment.Center,
                    ) {
                        when (key) {
                            '<' -> Icon(Icons.AutoMirrored.Outlined.Backspace, contentDescription = "Стереть")
                            '>' -> Icon(Icons.Filled.Check, contentDescription = "Готово", tint = MaterialTheme.colorScheme.onPrimary)
                            else -> Text("$key", fontSize = 26.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PinDots(length: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.height(20.dp)) {
        repeat(maxOf(length, MIN_PIN)) { i ->
            Box(
                Modifier.size(14.dp).clip(CircleShape).background(
                    if (i < length) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                )
            )
        }
    }
}

@Composable
private fun LockLayout(content: @Composable ColumnScope.() -> Unit) {
    Surface(color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
            content = content,
        )
    }
}

@Composable
fun SetupPinScreen(onDone: (String) -> Unit) {
    var first by remember { mutableStateOf<String?>(null) }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    LockLayout {
        Text("🌱", fontSize = 48.sp)
        Text("BeFree", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(
            "Всё, что ты здесь записываешь, хранится только на этом телефоне в зашифрованном виде. " +
                "Приложение не подключается к интернету и никуда ничего не отправляет.",
            textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            if (first == null) "Придумай PIN-код (4–8 цифр)" else "Повтори PIN-код",
            style = MaterialTheme.typography.titleMedium,
        )
        PinDots(pin.length)
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        PinPad(
            enabled = true,
            confirmEnabled = pin.length >= MIN_PIN,
            onDigit = { if (pin.length < MAX_PIN) pin += it; error = null },
            onBackspace = { pin = pin.dropLast(1) },
            onConfirm = {
                when {
                    first == null -> { first = pin; pin = "" }
                    first == pin -> onDone(pin)
                    else -> { error = "PIN-коды не совпали, попробуй ещё раз"; first = null; pin = "" }
                }
            },
        )
        Text(
            "Запомни PIN. Восстановить его нельзя — это цена полной приватности.",
            textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun LockScreen(pinManager: PinManager, activity: FragmentActivity, onUnlocked: () -> Unit, onWipe: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var lockMs by remember { mutableLongStateOf(pinManager.lockoutRemainingMs()) }
    var showWipe by remember { mutableStateOf(false) }
    val bioAvailable = remember { pinManager.biometricEnabled && canUseBiometric(activity) }

    LaunchedEffect(lockMs > 0) {
        while (lockMs > 0) { delay(1_000); lockMs = pinManager.lockoutRemainingMs() }
    }
    LaunchedEffect(Unit) { if (bioAvailable) showBiometricPrompt(activity, onUnlocked) }

    LockLayout {
        Text("🔒", fontSize = 44.sp)
        Text("BeFree", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Введи PIN-код", style = MaterialTheme.typography.titleMedium)
        PinDots(pin.length)
        when {
            lockMs > 0 -> Text("Слишком много попыток. Подожди ${lockMs / 1000 + 1} с", color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            error != null -> Text(error!!, color = MaterialTheme.colorScheme.error)
        }
        PinPad(
            enabled = lockMs == 0L,
            confirmEnabled = pin.length >= MIN_PIN,
            onDigit = { if (pin.length < MAX_PIN) pin += it; error = null },
            onBackspace = { pin = pin.dropLast(1) },
            onConfirm = {
                if (pinManager.verify(pin)) onUnlocked()
                else {
                    pin = ""
                    lockMs = pinManager.lockoutRemainingMs()
                    error = if (lockMs > 0) null else "Неверный PIN"
                }
            },
        )
        if (bioAvailable) {
            TextButton(onClick = { showBiometricPrompt(activity, onUnlocked) }) {
                Icon(Icons.Outlined.Fingerprint, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Войти по биометрии")
            }
        }
        TextButton(onClick = { showWipe = true }) { Text("Забыли PIN-код?") }
    }

    if (showWipe) WipeDialog(onConfirm = onWipe, onDismiss = { showWipe = false })
}
