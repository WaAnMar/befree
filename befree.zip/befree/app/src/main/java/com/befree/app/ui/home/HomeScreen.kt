package com.befree.app.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.befree.app.MainViewModel
import com.befree.app.data.*
import com.befree.app.ui.components.*
import com.befree.app.ui.library.LibraryContent
import com.befree.app.util.*
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private val milestones = listOf(1L, 3L, 7L, 14L, 30L, 60L, 90L, 180L, 365L)

@Composable
fun HomeScreen(
    vm: MainViewModel,
    onSettings: () -> Unit,
    onSos: () -> Unit,
    onQuickMood: (Int) -> Unit,
    onLogCraving: () -> Unit,
) {
    val addictions by vm.addictions.collectAsStateWithLifecycle()
    val moods by vm.moods.collectAsStateWithLifecycle()
    val cravings by vm.cravings.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Addiction?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); now = System.currentTimeMillis() } }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(greeting(now), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("BeFree", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, contentDescription = "Настройки") }
            }
        }

        if (addictions.isEmpty()) item {
            SoftCard(color = MaterialTheme.colorScheme.primaryContainer) {
                Text("Добро пожаловать 🌱", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Добавь то, от чего ты освобождаешься — вещество, игры, ставки. Счётчик будет показывать, сколько ты уже свободен(на).")
                Spacer(Modifier.height(4.dp))
                Button(onClick = { showAdd = true }) { Text("Начать") }
            }
        }

        items(addictions, key = { it.id }) { a ->
            StreakCard(a, now, onRelapse = { vm.registerRelapse(a) }, onEdit = { editing = a }, onDelete = { vm.deleteAddiction(a) })
        }

        if (addictions.isNotEmpty()) item {
            TextButton(onClick = { showAdd = true }) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Добавить ещё один трекер")
            }
        }

        item {
            SoftCard {
                Text("Как ты сейчас?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    moodLevels.forEach { level -> MoodBubble(level, selected = false, size = 52.dp) { onQuickMood(level.value) } }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SoftCard(Modifier.weight(1f), color = MaterialTheme.colorScheme.tertiaryContainer, onClick = onSos) {
                    Text("🆘", fontSize = 28.sp)
                    Text("SOS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Сильная тяга прямо сейчас", style = MaterialTheme.typography.bodySmall)
                }
                SoftCard(Modifier.weight(1f), color = MaterialTheme.colorScheme.secondaryContainer, onClick = onLogCraving) {
                    Text("🌊", fontSize = 28.sp)
                    Text("Записать тягу", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Что её вызвало?", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        item { WeekSummary(moods, cravings, now) }

        item {
            SoftCard(color = MaterialTheme.colorScheme.primaryContainer) {
                Text("💡 Совет дня", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(LibraryContent.tipOfDay())
            }
        }
    }

    if (showAdd) AddictionDialog(null, onDismiss = { showAdd = false }, onSave = { vm.saveAddiction(it); showAdd = false })
    editing?.let { a -> AddictionDialog(a, onDismiss = { editing = null }, onSave = { vm.saveAddiction(it); editing = null }) }
}

@Composable
private fun StreakCard(a: Addiction, now: Long, onRelapse: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val elapsed = (now - a.soberSince).coerceAtLeast(0)
    val days = elapsed / DAY_MS
    val hours = (elapsed % DAY_MS) / HOUR_MS
    val minutes = (elapsed % HOUR_MS) / MINUTE_MS
    val next = milestones.firstOrNull { it > days }
    val prev = milestones.lastOrNull { it <= days } ?: 0L
    var menu by remember { mutableStateOf(false) }
    var confirmRelapse by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    SoftCard(color = MaterialTheme.colorScheme.primaryContainer) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(a.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "Меню") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Изменить") }, onClick = { menu = false; onEdit() })
                    DropdownMenuItem(text = { Text("Отметить срыв") }, onClick = { menu = false; confirmRelapse = true })
                    DropdownMenuItem(text = { Text("Удалить трекер") }, onClick = { menu = false; confirmDelete = true })
                }
            }
        }
        Row(verticalAlignment = Alignment.Bottom) {
            Text("$days", fontSize = 56.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, lineHeight = 56.sp)
            Spacer(Modifier.width(10.dp))
            Text("${daysWord(days)} свободы", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 10.dp))
        }
        Text(
            "и ещё $hours ч $minutes мин · с ${formatDate(a.soberSince)}",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (next != null) {
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { ((days - prev).toFloat() / (next - prev)).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
            )
            val left = next - days
            Text("До отметки «$next ${daysWord(next)}» — $left ${daysWord(left)}", style = MaterialTheme.typography.bodySmall)
        } else {
            Text("Больше года свободы. Это огромный путь 💜", style = MaterialTheme.typography.bodySmall)
        }
        val extras = buildList {
            if (a.bestStreakMs > elapsed) add("Лучшая серия: ${a.bestStreakMs / DAY_MS} ${daysWord(a.bestStreakMs / DAY_MS)}")
            if (a.costPerDay > 0) add("Сохранено: ${formatMoney(a.costPerDay * elapsed / DAY_MS)}")
        }
        if (extras.isNotEmpty()) Text(extras.joinToString(" · "), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
    }

    if (confirmRelapse) ConfirmDialog(
        title = "Был срыв?",
        text = "Срыв — не провал, а информация. Счётчик начнётся заново, но твоя лучшая серия и весь опыт сохранятся. " +
            "Если сможешь, запиши в трекере тяги, что к этому привело — так будет легче подготовиться в следующий раз.",
        confirmText = "Начать заново",
        onConfirm = { confirmRelapse = false; onRelapse() },
        onDismiss = { confirmRelapse = false },
    )
    if (confirmDelete) ConfirmDialog(
        title = "Удалить трекер «${a.name}»?",
        text = "Счётчик и лучшая серия будут удалены. Записи настроения и тяги останутся.",
        confirmText = "Удалить",
        onConfirm = { confirmDelete = false; onDelete() },
        onDismiss = { confirmDelete = false },
    )
}

@Composable
private fun WeekSummary(moods: List<MoodEntry>, cravings: List<CravingEntry>, now: Long) {
    val weekAgo = now - 7 * DAY_MS
    val wm = moods.filter { it.timestamp >= weekAgo }
    val wc = cravings.filter { it.timestamp >= weekAgo }
    val resisted = wc.count { it.outcome == Outcome.RESISTED }
    SoftCard {
        Text("Последние 7 дней", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth()) {
            StatItem(if (wm.isEmpty()) "—" else moodOf(wm.map { it.mood }.average().roundToInt()).emoji, "настроение в среднем")
            StatItem("${wm.size}", "отметок настроения")
            StatItem("$resisted из ${wc.size}", "волн тяги пережито")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
private object PastDates : SelectableDates {
    override fun isSelectableDate(utcTimeMillis: Long) = utcTimeMillis <= System.currentTimeMillis()
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun AddictionDialog(initial: Addiction?, onDismiss: () -> Unit, onSave: (Addiction) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var since by remember { mutableLongStateOf(initial?.soberSince ?: System.currentTimeMillis()) }
    var cost by remember { mutableStateOf(initial?.costPerDay?.takeIf { it > 0 }?.let(::formatPlain) ?: "") }
    var picker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Новый трекер" else "Изменить трекер") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("От чего освобождаюсь") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    addictionSuggestions.forEach { s -> SuggestionChip(onClick = { name = s }, label = { Text(s) }) }
                }
                OutlinedButton(onClick = { picker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Свободен(на) с: ${formatDate(since)}")
                }
                OutlinedTextField(
                    cost, { v -> cost = v.filter { it.isDigit() || it == '.' || it == ',' } },
                    label = { Text("Тратил(а) в день — необязательно") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                val base = initial ?: Addiction(name = "", soberSince = since)
                onSave(base.copy(name = name.trim(), soberSince = since, costPerDay = parseAmount(cost) ?: 0.0))
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )

    if (picker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = localToUtcDate(since), selectableDates = PastDates)
        DatePickerDialog(
            onDismissRequest = { picker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let {
                        val picked = utcDateToLocal(it)
                        if (!isSameDay(picked, since)) since = picked
                    }
                    picker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { picker = false }) { Text("Отмена") } },
        ) { DatePicker(state) }
    }
}
