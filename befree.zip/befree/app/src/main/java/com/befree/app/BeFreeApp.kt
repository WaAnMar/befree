package com.befree.app

import android.app.Application
import android.content.Context
import com.befree.app.data.AppDatabase
import com.befree.app.data.BeFreeDao
import com.befree.app.security.AppLock
import com.befree.app.security.KeyManager
import com.befree.app.security.PinManager

class BeFreeApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        AppLock.init()
    }
}

class AppContainer(private val context: Context) {
    val pinManager = PinManager(context)

    private val database = lazy {
        AppDatabase.create(context, KeyManager.getOrCreateDbPassphrase(context))
    }
    val dao: BeFreeDao get() = database.value.dao()

    /** Полное безвозвратное удаление: база, ключи, PIN. */
    fun wipeEverything() {
        if (database.isInitialized()) database.value.close()
        context.deleteDatabase(AppDatabase.NAME)
        KeyManager.deleteAll(context)
        pinManager.clear()
    }
}
