package com.befree.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Mint = Color(0xFF4CC9A0)
val Peach = Color(0xFFFF9F7A)
val Sky = Color(0xFF6BB8FF)
val Rose = Color(0xFFFF6B8A)
val Sun = Color(0xFFFFC857)

private val Light = lightColorScheme(
    primary = Color(0xFF7C6FE0), onPrimary = Color.White,
    primaryContainer = Color(0xFFE9E5FF), onPrimaryContainer = Color(0xFF2A2170),
    secondary = Color(0xFF2FA982), onSecondary = Color.White,
    secondaryContainer = Color(0xFFD7F5EA), onSecondaryContainer = Color(0xFF0E4A37),
    tertiary = Color(0xFFE5764F), tertiaryContainer = Color(0xFFFFE6DC), onTertiaryContainer = Color(0xFF5A2410),
    background = Color(0xFFF7F5FF), onBackground = Color(0xFF1D1B2E),
    surface = Color(0xFFF7F5FF), onSurface = Color(0xFF1D1B2E),
    surfaceVariant = Color(0xFFECE9F7), onSurfaceVariant = Color(0xFF5B5873),
    surfaceContainer = Color.White, surfaceContainerLow = Color.White,
    surfaceContainerHigh = Color(0xFFF1EEFB),
    error = Color(0xFFD64560), errorContainer = Color(0xFFFFE1E6), onErrorContainer = Color(0xFF5E0B1C),
)

private val Dark = darkColorScheme(
    primary = Color(0xFFB9B0FF), onPrimary = Color(0xFF231A66),
    primaryContainer = Color(0xFF3B3190), onPrimaryContainer = Color(0xFFE9E5FF),
    secondary = Color(0xFF7FE0BF), onSecondary = Color(0xFF003828),
    secondaryContainer = Color(0xFF145C45), onSecondaryContainer = Color(0xFFD7F5EA),
    tertiary = Color(0xFFFFB79B), tertiaryContainer = Color(0xFF6E3219), onTertiaryContainer = Color(0xFFFFE6DC),
    background = Color(0xFF14131C), onBackground = Color(0xFFE7E4F5),
    surface = Color(0xFF14131C), onSurface = Color(0xFFE7E4F5),
    surfaceVariant = Color(0xFF2A2838), onSurfaceVariant = Color(0xFFC6C2DA),
    surfaceContainer = Color(0xFF1F1E2A), surfaceContainerLow = Color(0xFF1F1E2A),
    surfaceContainerHigh = Color(0xFF292836),
    error = Color(0xFFFF8FA3), errorContainer = Color(0xFF5E0B1C), onErrorContainer = Color(0xFFFFE1E6),
)

private val BeFreeShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
)

@Composable
fun BeFreeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        shapes = BeFreeShapes,
        content = content,
    )
}
