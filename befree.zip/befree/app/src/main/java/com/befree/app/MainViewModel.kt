package com.befree.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.befree.app.data.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(private val dao: BeFreeDao) : ViewModel() {

    private fun <T> Flow<List<T>>.state(): StateFlow<List<T>> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val addictions = dao.addictions().state()
    val moods = dao.moods().state()
    val cravings = dao.cravings().state()
    val goals = dao.goals().state()

    fun saveAddiction(a: Addiction) = viewModelScope.launch { dao.upsertAddiction(a) }
    fun deleteAddiction(a: Addiction) = viewModelScope.launch { dao.deleteAddiction(a) }

    fun registerRelapse(a: Addiction) = viewModelScope.launch {
        val now = System.currentTimeMillis()
        dao.upsertAddiction(
            a.copy(
                soberSince = now,
                bestStreakMs = maxOf(a.bestStreakMs, now - a.soberSince),
                relapseCount = a.relapseCount + 1,
            )
        )
    }

    fun addMood(m: MoodEntry) = viewModelScope.launch { dao.insertMood(m) }
    fun deleteMood(m: MoodEntry) = viewModelScope.launch { dao.deleteMood(m) }

    fun addCraving(c: CravingEntry) = viewModelScope.launch { dao.insertCraving(c) }
    fun deleteCraving(c: CravingEntry) = viewModelScope.launch { dao.deleteCraving(c) }

    fun saveGoal(g: Goal) = viewModelScope.launch { dao.upsertGoal(g) }
    fun deleteGoal(g: Goal) = viewModelScope.launch { dao.deleteGoal(g) }

    fun toggleGoal(g: Goal) = saveGoal(
        g.copy(done = !g.done, doneAt = if (!g.done) System.currentTimeMillis() else null)
    )

    fun addPayment(g: Goal, amount: Double) {
        val paid = g.paidAmount + amount
        val finished = g.targetAmount != null && paid >= g.targetAmount
        saveGoal(
            g.copy(
                paidAmount = paid,
                done = g.done || finished,
                doneAt = if (finished && !g.done) System.currentTimeMillis() else g.doneAt,
            )
        )
    }

    companion object {
        fun factory(dao: BeFreeDao) = viewModelFactory { initializer { MainViewModel(dao) } }
    }
}
