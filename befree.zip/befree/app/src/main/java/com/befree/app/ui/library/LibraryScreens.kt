package com.befree.app.ui.library

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.befree.app.ui.components.*

@Composable
fun LibraryScreen(onOpen: (String) -> Unit) {
    val uri = LocalUriHandler.current
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenHeader("Знания", "Техники, статьи, книги и помощь") }
        item {
            SoftCard(color = MaterialTheme.colorScheme.tertiaryContainer) {
                Text(
                    "BeFree — помощник, а не замена врачу или терапевту. Резкий отказ от алкоголя, бензодиазепинов и некоторых других веществ может быть опасен — проходи отмену под наблюдением врача.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
        LibraryContent.categories.forEach { cat ->
            item { SectionTitle(cat) }
            items(LibraryContent.articles.filter { it.category == cat }, key = { it.id }) { a ->
                SoftCard(onClick = { onOpen(a.id) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(a.emoji, fontSize = 28.sp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(a.title, fontWeight = FontWeight.SemiBold)
                            Text(a.summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item { SectionTitle("📚 Полезные книги") }
        items(LibraryContent.books) { b ->
            SoftCard {
                Text(b.title, fontWeight = FontWeight.SemiBold)
                Text(b.author, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                Text(b.note, style = MaterialTheme.typography.bodyMedium)
            }
        }
        item { SectionTitle("🆘 Где найти помощь") }
        items(LibraryContent.help) { h ->
            SoftCard(onClick = { runCatching { uri.openUri(h.url) } }) {
                Text(h.title, fontWeight = FontWeight.SemiBold)
                Text(h.description, style = MaterialTheme.typography.bodyMedium)
                Text(h.url.removePrefix("tel:"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
        }
        item {
            Text(
                "Ссылки открываются во внешнем браузере. Само приложение не имеет доступа к интернету.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun ArticleScreen(id: String, onBack: () -> Unit) {
    val a = LibraryContent.article(id)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(a?.category ?: "Статья", onBack = onBack)
        if (a == null) { Text("Статья не найдена"); return@Column }
        Text(a.emoji, fontSize = 44.sp)
        Text(a.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        a.body.split("\n\n").forEach { p ->
            Text(p, style = MaterialTheme.typography.bodyLarge, lineHeight = 26.sp)
        }
    }
}
