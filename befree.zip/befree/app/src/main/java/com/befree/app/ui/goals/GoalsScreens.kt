package com.befree.app.ui.goals

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.befree.app.MainViewModel
import com.befree.app.data.Goal
import com.befree.app.data.GoalType
import com.befree.app.data.goalTemplates
import com.befree.app.ui.components.*
import com.befree.app.util.formatMoney
import com.befree.app.util.parseAmount

private fun typeLabel(t: String) = when (t) {
    GoalType.PRACTICAL -> "Практичные"
    GoalType.SPIRITUAL -> "Духовные"
    else -> "Возмещение ущерба"
}

private fun typeInfo(t: String) = when (t) {
    GoalType.PRACTICAL -> "Конкретные шаги в быту: деньги, работа, здоровье, окружение. " +
        "Делай цели маленькими и измеримыми: «звонить наставнику каждый вечер» работает лучше, чем «стать лучше»."
    GoalType.SPIRITUAL -> "То, что наполняет жизнь смыслом: ценности, благодарность, помощь другим, " +
        "молитва или медитация — в той форме, которая близка именно тебе."
    else -> "Список людей, которым зависимость причинила вред, и план, как это исправить. " +
        "Не спеши: сначала подготовка, лучше вместе с наставником или терапевтом. " +
        "Возмещение не должно ранить ни этого человека, ни других."
}

@Composable
fun GoalsScreen(vm: MainViewModel, onNew: (String) -> Unit) {
    val goals by vm.goals.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf(GoalType.PRACTICAL) }
    var paying by remember { mutableStateOf<Goal?>(null) }
    var toDelete by remember { mutableStateOf<Goal?>(null) }
    val list = goals.filter { it.type == tab }
    val active = list.filterNot { it.done }
    val done = list.filter { it.done }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenHeader("Цели", "Маленькие шаги к свободной жизни") }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GoalType.all.forEach { t ->
                    val count = goals.count { it.type == t && !it.done }
                    FilterChip(
                        selected = tab == t, onClick = { tab = t },
                        label = { Text(if (count > 0) "${typeLabel(t)} · $count" else typeLabel(t)) },
                    )
                }
            }
        }
        item { SoftCard(color = MaterialTheme.colorScheme.secondaryContainer) { Text(typeInfo(tab), style = MaterialTheme.typography.bodyMedium) } }
        item { Button(onClick = { onNew(tab) }, modifier = Modifier.fillMaxWidth()) { Text("Новая цель") } }

        if (list.isEmpty()) item { EmptyState("🎯", "Здесь пока пусто", "Начни с одной маленькой цели, которую реально сделать на этой неделе.") }
        items(active, key = { it.id }) { g ->
            GoalCard(g, onToggle = { vm.toggleGoal(g) }, onPay = { paying = g }, onDelete = { toDelete = g })
        }
        if (done.isNotEmpty()) item { SectionTitle("Выполнено ✨") }
        items(done, key = { it.id }) { g ->
            GoalCard(g, onToggle = { vm.toggleGoal(g) }, onPay = { paying = g }, onDelete = { toDelete = g })
        }
    }

    paying?.let { g -> PaymentDialog(g, onDismiss = { paying = null }, onPay = { vm.addPayment(g, it); paying = null }) }
    toDelete?.let { g ->
        ConfirmDialog("Удалить цель?", "«${g.title}» будет удалена без возможности восстановления.", "Удалить",
            onConfirm = { vm.deleteGoal(g); toDelete = null }, onDismiss = { toDelete = null })
    }
}

@Composable
private fun GoalCard(g: Goal, onToggle: () -> Unit, onPay: () -> Unit, onDelete: () -> Unit) {
    SoftCard {
        Row(verticalAlignment = Alignment.Top) {
            Checkbox(checked = g.done, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f).padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    g.title, fontWeight = FontWeight.SemiBold,
                    textDecoration = if (g.done) TextDecoration.LineThrough else null,
                )
                if (g.person.isNotBlank()) LabeledText("Кому", g.person)
                if (g.harm.isNotBlank()) LabeledText("Что произошло", g.harm)
                if (g.description.isNotBlank()) {
                    if (g.type == GoalType.AMENDS) LabeledText("План", g.description) else Text(g.description, style = MaterialTheme.typography.bodyMedium)
                }
            }
            IconButton(onClick = onDelete) { Icon(Icons.Outlined.Delete, contentDescription = "Удалить") }
        }
        g.targetAmount?.let { target ->
            LinearProgressIndicator(
                progress = { if (target <= 0) 0f else (g.paidAmount / target).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = MaterialTheme.colorScheme.secondary,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${formatMoney(g.paidAmount)} из ${formatMoney(target)}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                if (!g.done) TextButton(onClick = onPay) { Text("Внести платёж") }
            }
        }
    }
}

@Composable
private fun PaymentDialog(g: Goal, onDismiss: () -> Unit, onPay: (Double) -> Unit) {
    var text by remember { mutableStateOf("") }
    val amount = parseAmount(text)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Платёж") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Каждый, даже небольшой платёж — это шаг. «${g.title}»")
                OutlinedTextField(
                    text, { v -> text = v.filter { it.isDigit() || it == '.' || it == ',' } },
                    label = { Text("Сумма") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                )
            }
        },
        confirmButton = { TextButton(enabled = amount != null && amount > 0, onClick = { onPay(amount!!) }) { Text("Внести") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GoalEditorScreen(initialType: String, onSave: (Goal) -> Unit, onBack: () -> Unit) {
    var type by remember { mutableStateOf(if (initialType in GoalType.all) initialType else GoalType.PRACTICAL) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var person by remember { mutableStateOf("") }
    var harm by remember { mutableStateOf("") }
    var hasAmount by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        ScreenHeader("Новая цель", onBack = onBack)
        SingleChipSelector(GoalType.all.map { it to typeLabel(it) }, type) { type = it }

        SectionTitle("Идеи")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            goalTemplates[type].orEmpty().forEach { t -> SuggestionChip(onClick = { title = t }, label = { Text(t) }) }
        }

        OutlinedTextField(title, { title = it }, label = { Text("Цель") }, singleLine = true, modifier = Modifier.fillMaxWidth())

        if (type == GoalType.AMENDS) {
            OutlinedTextField(person, { person = it }, label = { Text("Кому я причинил(а) вред") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(harm, { harm = it }, label = { Text("Что произошло") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        }
        OutlinedTextField(
            description, { description = it },
            label = { Text(if (type == GoalType.AMENDS) "Как я планирую это исправить" else "Первые шаги / детали") },
            minLines = 3, modifier = Modifier.fillMaxWidth(),
        )

        if (type != GoalType.SPIRITUAL) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Есть сумма", fontWeight = FontWeight.Medium)
                    Text("Долг, возврат денег, накопления", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = hasAmount, onCheckedChange = { hasAmount = it })
            }
            if (hasAmount) OutlinedTextField(
                amount, { v -> amount = v.filter { it.isDigit() || it == '.' || it == ',' } },
                label = { Text("Сумма") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
            )
        }

        if (type == GoalType.AMENDS) {
            Text(
                "Подсказка: прежде чем идти к человеку, обсуди план с кем-то, кому доверяешь. " +
                    "Подробнее — в разделе «Знания» → «Возмещение ущерба».",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Button(
            enabled = title.isNotBlank(),
            onClick = {
                onSave(
                    Goal(
                        type = type, title = title.trim(), description = description.trim(),
                        person = if (type == GoalType.AMENDS) person.trim() else "",
                        harm = if (type == GoalType.AMENDS) harm.trim() else "",
                        targetAmount = if (hasAmount && type != GoalType.SPIRITUAL) parseAmount(amount)?.takeIf { it > 0 } else null,
                    )
                )
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text("Сохранить") }
    }
}
