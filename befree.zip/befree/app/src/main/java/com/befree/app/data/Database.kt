package com.befree.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

class Converters {
    @TypeConverter fun fromList(v: List<String>): String = v.joinToString(SEP)
    @TypeConverter fun toList(v: String): List<String> = if (v.isEmpty()) emptyList() else v.split(SEP)
    private companion object { const val SEP = "\u001F" }
}

@Dao
interface BeFreeDao {
    @Query("SELECT * FROM addictions ORDER BY id") fun addictions(): Flow<List<Addiction>>
    @Upsert suspend fun upsertAddiction(a: Addiction)
    @Delete suspend fun deleteAddiction(a: Addiction)

    @Query("SELECT * FROM moods ORDER BY timestamp DESC") fun moods(): Flow<List<MoodEntry>>
    @Insert suspend fun insertMood(m: MoodEntry)
    @Delete suspend fun deleteMood(m: MoodEntry)

    @Query("SELECT * FROM cravings ORDER BY timestamp DESC") fun cravings(): Flow<List<CravingEntry>>
    @Insert suspend fun insertCraving(c: CravingEntry)
    @Delete suspend fun deleteCraving(c: CravingEntry)

    @Query("SELECT * FROM goals ORDER BY done, createdAt DESC") fun goals(): Flow<List<Goal>>
    @Upsert suspend fun upsertGoal(g: Goal)
    @Delete suspend fun deleteGoal(g: Goal)
}

@Database(
    entities = [Addiction::class, MoodEntry::class, CravingEntry::class, Goal::class],
    version = 1,
    exportSchema = false,
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): BeFreeDao

    companion object {
        const val NAME = "befree.db"

        /** База целиком зашифрована SQLCipher (AES-256). Ключ — из Android Keystore. */
        fun create(context: Context, passphrase: ByteArray): AppDatabase {
            System.loadLibrary("sqlcipher")
            return Room.databaseBuilder(context, AppDatabase::class.java, NAME)
                .openHelperFactory(SupportOpenHelperFactory(passphrase))
                .build()
        }
    }
}
