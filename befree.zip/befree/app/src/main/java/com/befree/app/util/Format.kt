package com.befree.app.util

import java.text.SimpleDateFormat
import java.util.*

const val MINUTE_MS = 60_000L
const val HOUR_MS = 60 * MINUTE_MS
const val DAY_MS = 24 * HOUR_MS

private val ru: Locale = Locale.forLanguageTag("ru")

fun formatDateTime(ts: Long): String = SimpleDateFormat("d MMM, HH:mm", ru).format(Date(ts))
fun formatDate(ts: Long): String = SimpleDateFormat("d MMMM yyyy", ru).format(Date(ts))

fun ruPlural(n: Long, one: String, few: String, many: String): String {
    val n10 = (n % 10).toInt(); val n100 = (n % 100).toInt()
    return when {
        n10 == 1 && n100 != 11 -> one
        n10 in 2..4 && n100 !in 12..14 -> few
        else -> many
    }
}

fun daysWord(n: Long) = ruPlural(n, "день", "дня", "дней")

fun startOfDay(ts: Long): Long = Calendar.getInstance().apply {
    timeInMillis = ts
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun hourOf(ts: Long): Int = Calendar.getInstance().apply { timeInMillis = ts }.get(Calendar.HOUR_OF_DAY)

fun isSameDay(a: Long, b: Long) = startOfDay(a) == startOfDay(b)

/** DatePicker работает в UTC-полуночи; переводим в локальную дату и обратно. */
fun utcDateToLocal(utcMs: Long): Long {
    val utc = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = utcMs }
    return Calendar.getInstance().apply {
        clear()
        set(utc.get(Calendar.YEAR), utc.get(Calendar.MONTH), utc.get(Calendar.DAY_OF_MONTH))
    }.timeInMillis
}

fun localToUtcDate(localMs: Long): Long {
    val local = Calendar.getInstance().apply { timeInMillis = localMs }
    return Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        clear()
        set(local.get(Calendar.YEAR), local.get(Calendar.MONTH), local.get(Calendar.DAY_OF_MONTH))
    }.timeInMillis
}

fun formatMoney(v: Double): String = String.format(ru, "%,.0f", v)

fun parseAmount(s: String): Double? = s.replace(" ", "").replace(',', '.').toDoubleOrNull()

fun formatPlain(v: Double): String = if (v % 1.0 == 0.0) v.toLong().toString() else v.toString()

fun greeting(ts: Long): String = when (hourOf(ts)) {
    in 5..11 -> "Доброе утро"
    in 12..17 -> "Добрый день"
    in 18..22 -> "Добрый вечер"
    else -> "Доброй ночи"
}
