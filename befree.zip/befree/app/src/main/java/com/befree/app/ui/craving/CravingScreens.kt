package com.befree.app.ui.craving

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.befree.app.MainViewModel
import com.befree.app.data.*
import com.befree.app.ui.components.*
import com.befree.app.ui.theme.Mint
import com.befree.app.ui.theme.Rose
import com.befree.app.ui.theme.Sun
import com.befree.app.util.*
import java.util.Locale
import kotlin.math.roundToInt

private fun intensityColor(i: Int): Color = lerp(Mint, Rose, ((i - 1) / 9f).coerceIn(0f, 1f))

private val outcomeOptions = listOf(
    Outcome.RESISTED to "Устоял(а) 💪",
    Outcome.PARTIAL to "Частично",
    Outcome.USED to "Был срыв",
)

private fun outcomeLabel(o: String) = outcomeOptions.firstOrNull { it.first == o }?.second ?: o
private fun outcomeColor(o: String) = when (o) { Outcome.RESISTED -> Mint; Outcome.PARTIAL -> Sun; else -> Rose }

@Composable
fun CravingScreen(vm: MainViewModel, onNew: () -> Unit, onSos: () -> Unit) {
    val cravings by vm.cravings.collectAsStateWithLifecycle()
    var toDelete by remember { mutableStateOf<CravingEntry?>(null) }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { ScreenHeader("Тяга", "Когда, где и почему она приходит") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onNew, modifier = Modifier.weight(1f)) { Text("Записать тягу") }
                FilledTonalButton(
                    onClick = onSos, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                ) { Text("🆘 SOS") }
            }
        }
        if (cravings.isEmpty()) {
            item {
                EmptyState("🌊", "Пока пусто",
                    "Записывай каждую тягу — даже слабую. Через пару недель станет видно, какие ситуации, люди и чувства её запускают, и что помогает именно тебе.")
            }
        } else {
            item { CravingStats(cravings) }
            item { SectionTitle("История") }
            items(cravings, key = { it.id }) { c -> CravingRow(c, onDelete = { toDelete = c }) }
        }
    }

    toDelete?.let { c ->
        ConfirmDialog("Удалить запись?", "Это действие нельзя отменить.", "Удалить",
            onConfirm = { vm.deleteCraving(c); toDelete = null }, onDismiss = { toDelete = null })
    }
}

@Composable
private fun CravingStats(all: List<CravingEntry>) {
    val recent = all.filter { it.timestamp >= System.currentTimeMillis() - 30 * DAY_MS }
    SoftCard {
        Text("Последние 30 дней", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (recent.isEmpty()) {
            Text("За последний месяц записей нет.")
            return@SoftCard
        }
        val resisted = recent.count { it.outcome == Outcome.RESISTED }
        Row(Modifier.fillMaxWidth()) {
            StatItem("${recent.size}", "эпизодов")
            StatItem("${resisted * 100 / recent.size}%", "пережито без срыва")
            StatItem(String.format(Locale.US, "%.1f", recent.map { it.intensity }.average()), "средняя сила")
        }

        val triggers = recent.flatMap { it.triggers + it.halt }.groupingBy { it }.eachCount()
            .entries.sortedByDescending { it.value }.take(5)
        if (triggers.isNotEmpty()) {
            SectionTitle("Частые триггеры")
            val max = triggers.first().value
            triggers.forEach { BarRow(it.key, it.value, max) }
        }

        val parts = listOf(
            "Ночь (0–6)" to 0..5, "Утро (6–12)" to 6..11,
            "День (12–18)" to 12..17, "Вечер (18–24)" to 18..23,
        ).map { (label, range) -> label to recent.count { hourOf(it.timestamp) in range } }
        SectionTitle("Время суток")
        val pMax = parts.maxOf { it.second }
        parts.forEach { BarRow(it.first, it.second, pMax, MaterialTheme.colorScheme.secondary) }

        val helpful = recent.filter { it.outcome == Outcome.RESISTED }.flatMap { it.coping }
            .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(3)
        if (helpful.isNotEmpty()) {
            SectionTitle("Что помогает тебе устоять")
            Text(helpful.joinToString(" · ") { it.key }, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun CravingRow(c: CravingEntry, onDelete: () -> Unit) {
    val color = intensityColor(c.intensity)
    SoftCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(color.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                Text("${c.intensity}", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(outcomeLabel(c.outcome), fontWeight = FontWeight.SemiBold, color = outcomeColor(c.outcome))
                Text(
                    listOf(c.addiction, formatDateTime(c.timestamp)).filter { it.isNotBlank() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = onDelete) { Icon(Icons.Outlined.Delete, contentDescription = "Удалить") }
        }
        val triggers = c.triggers + c.halt
        if (triggers.isNotEmpty()) LabeledText("Триггеры", triggers.joinToString(", "))
        if (c.place.isNotBlank()) LabeledText("Где", c.place)
        if (c.company.isNotEmpty()) LabeledText("С кем", c.company.joinToString(", "))
        if (c.thoughts.isNotBlank()) LabeledText("Мысли", c.thoughts)
        if (c.coping.isNotEmpty()) LabeledText("Что делал(а)", c.coping.joinToString(", "))
        durationOptions.firstOrNull { it.first == c.durationMin && it.first != 0 }?.let { LabeledText("Длилась", it.second.lowercase()) }
        if (c.note.isNotBlank()) LabeledText("Заметка", c.note)
    }
}

@Composable
fun CravingEditorScreen(addictionNames: List<String>, onSave: (CravingEntry) -> Unit, onBack: () -> Unit) {
    var addiction by remember(addictionNames) { mutableStateOf(addictionNames.singleOrNull() ?: "") }
    var intensity by remember { mutableFloatStateOf(5f) }
    var triggers by remember { mutableStateOf(setOf<String>()) }
    var halt by remember { mutableStateOf(setOf<String>()) }
    var place by remember { mutableStateOf("") }
    var company by remember { mutableStateOf(setOf<String>()) }
    var thoughts by remember { mutableStateOf("") }
    var coping by remember { mutableStateOf(setOf<String>()) }
    var duration by remember { mutableIntStateOf(0) }
    var outcome by remember { mutableStateOf(Outcome.RESISTED) }
    var note by remember { mutableStateOf("") }
    val color = intensityColor(intensity.roundToInt())

    Column(
        Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        ScreenHeader("Тяга", "Запиши, пока помнишь детали", onBack = onBack)

        if (addictionNames.size > 1) {
            SectionTitle("К чему тяга")
            SingleChipSelector(addictionNames.map { it to it }, addiction) { addiction = it }
        }

        SectionTitle("Сила тяги")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Slider(
                value = intensity, onValueChange = { intensity = it }, valueRange = 1f..10f, steps = 8,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color),
            )
            Spacer(Modifier.width(12.dp))
            Text("${intensity.roundToInt()}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        SectionTitle("Что её запустило")
        ChipSelector(triggerOptions, triggers) { triggers = triggers.toggle(it) }

        SectionTitle("HALT — в каком ты состоянии")
        ChipSelector(haltOptions, halt) { halt = halt.toggle(it) }

        SectionTitle("Где это было")
        OutlinedTextField(place, { place = it }, placeholder = { Text("Дома, по дороге с работы, в баре…") }, singleLine = true, modifier = Modifier.fillMaxWidth())

        SectionTitle("С кем")
        ChipSelector(companyOptions, company) { company = company.toggle(it) }

        SectionTitle("Какие были мысли")
        OutlinedTextField(thoughts, { thoughts = it }, placeholder = { Text("«Один раз можно», «я заслужил(а)», «никто не узнает»…") }, minLines = 2, modifier = Modifier.fillMaxWidth())

        SectionTitle("Что ты сделал(а)")
        ChipSelector(copingOptions, coping) { coping = coping.toggle(it) }

        SectionTitle("Сколько она длилась")
        SingleChipSelector(durationOptions, duration) { duration = it }

        SectionTitle("Чем закончилось")
        SingleChipSelector(outcomeOptions, outcome) { outcome = it }
        if (outcome == Outcome.USED) {
            Text(
                "Спасибо за честность. Срыв — не конец пути. Загляни в раздел «Знания» → «Срыв — не конец», там есть план, что делать дальше.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        SectionTitle("Заметка")
        OutlinedTextField(note, { note = it }, minLines = 2, modifier = Modifier.fillMaxWidth())

        Button(
            onClick = {
                onSave(
                    CravingEntry(
                        addiction = addiction, intensity = intensity.roundToInt(),
                        triggers = triggers.toList(), halt = halt.toList(), place = place.trim(),
                        company = company.toList(), thoughts = thoughts.trim(), coping = coping.toList(),
                        durationMin = duration, outcome = outcome, note = note.trim(),
                    )
                )
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text("Сохранить") }
    }
}
